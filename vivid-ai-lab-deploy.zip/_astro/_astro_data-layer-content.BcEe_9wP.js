const _astro_dataLayerContent = new Map();

export { _astro_dataLayerContent as default };
