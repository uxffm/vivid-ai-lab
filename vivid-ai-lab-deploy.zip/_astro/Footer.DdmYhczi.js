import { jsx, jsxs } from 'react/jsx-runtime';
import * as React from 'react';
import { useState, useEffect } from 'react';
import { X, Menu, Send } from 'lucide-react';
import { Slot } from '@radix-ui/react-slot';
import { cva } from 'class-variance-authority';
import { clsx } from 'clsx';
import { twMerge } from 'tailwind-merge';

function cn(...inputs) {
  return twMerge(clsx(inputs));
}

const buttonVariants = cva(
  "inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-[5px] text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0",
  {
    variants: {
      variant: {
        default: "bg-primary text-primary-foreground hover:bg-primary/90",
        destructive: "bg-destructive text-destructive-foreground hover:bg-destructive/90",
        outline: "border border-input bg-background hover:bg-accent hover:text-accent-foreground",
        secondary: "bg-secondary text-secondary-foreground hover:bg-secondary/80",
        ghost: "hover:bg-accent hover:text-accent-foreground",
        link: "text-primary underline-offset-4 hover:underline",
        hero: "hero-gradient text-white hover:scale-105 glow-effect smooth-transition border-0 shadow-2xl",
        glass: "bg-white/10 backdrop-blur-sm border border-white/20 text-white hover:bg-white/20 smooth-transition"
      },
      size: {
        default: "h-10 px-4 py-2",
        sm: "h-9 rounded-[5px] px-3",
        lg: "h-11 rounded-[5px] px-8",
        icon: "h-10 w-10"
      }
    },
    defaultVariants: {
      variant: "default",
      size: "default"
    }
  }
);
const Button = React.forwardRef(
  ({ className, variant, size, asChild = false, ...props }, ref) => {
    const Comp = asChild ? Slot : "button";
    return /* @__PURE__ */ jsx(
      Comp,
      {
        className: cn(buttonVariants({ variant, size, className })),
        ref,
        ...props
      }
    );
  }
);
Button.displayName = "Button";

const homepageContent = {
  // Hero Section
  hero: {
    title: {
      line1: "Ihre KI Agentur",
      line2: "aus Frankfurt am Main."
    },
    subtitle: "KI nutzen und live miterleben. Wir sind Ihre KI-Agentur aus Frankfurt am Main und revolutionieren Ihren digitalen Auftritt mit intelligenten Lösungen, die messbare Ergebnisse liefern. Ganz nah an der KI Entwicklung dran, nutzen wir die modernsten KI Methoden.",
    buttons: {
      primary: {
        text: "Unseren KI Service entdecken",
        href: "#services"
      },
      secondary: {
        text: "Direkt Kontaktieren",
        href: "#contact"
      }
    },
    trust: "Vertraut von 20+ Unternehmen aus Frankfurt und Umgebung"
  },
  // Navigation
  navigation: {
    logo: "KI Agentur Frankfurt",
    menu: [
      { label: "Services", href: "#services" },
      { label: "Über uns", href: "#about" },
      { label: "Blog", href: "#blog" },
      { label: "Kontakt", href: "#contact" }
    ],
    cta: "Kostenlose Beratung"
  },
  // Services Section
  services: {
    title: "Unsere KI-Services",
    subtitle: "Wir bieten maßgeschneiderte KI-Lösungen für Ihr Unternehmen - von Chatbots über Prozessautomatisierung bis hin zu modernem Webdesign. Alle Lösungen sind kostengünstig, effizient und auf Ihre spezifischen Bedürfnisse zugeschnitten. Mit KI können Sie die langweiligen, repetitiven Aufgaben Ihres Unternehmens automatisieren, ohne auf teure Freelancer zurückgreifen zu müssen.",
    services: [
      {
        title: "KI Chatbots einfügen",
        description: "Intelligente Chatbots, die Ihre Kunden 24/7 unterstützen und Ihre Conversion-Raten steigern. Sparen Sie Zeit und Personal durch automatische Kundenbetreuung rund um die Uhr.",
        icon: "🤖"
      },
      {
        title: "KI Automation",
        description: "Automatisierung aller Prozesse mit KI-Technologie - egal welche Abläufe Sie optimieren möchten. Reduzieren Sie manuelle Arbeit und steigern Sie die Effizienz Ihres Teams.",
        icon: "⚡"
      },
      {
        title: "KI-gestütztes Mediendesign",
        description: "Professionelle Mediendesigns, die mit KI-Unterstützung erstellt werden für optimale Ergebnisse. Erhalten Sie einzigartige Designs in Rekordzeit und zu einem Bruchteil der üblichen Kosten.",
        icon: "🎨"
      },
      {
        title: "KI-gestütztes Webdesign",
        description: "Moderne Websites mit KI-Unterstützung - der große Vorteil: Es ist günstig und modern! Erstellen Sie professionelle Webauftritte ohne teure Designer oder Entwickler.",
        icon: "🌐"
      }
    ]
  },
  // About Section
  about: {
    title: "Über uns",
    subtitle: "Ihre Experten für KI-Marketing in Frankfurt",
    description: "Wir sind ein Team aus SEO-Experten, Designern und Programmierern, die mit der KI ganz früh angefangen haben. Die KI-Technologie ändert sich täglich - nichts entwickelt sich so schnell wie die künstliche Intelligenz. Als KI-Agentur wissen wir genau, welche KI-Technologie für welche Aufgabe die richtige ist. Wir setzen alle diese Änderungen sofort für unsere Kunden um und bleiben immer am Puls der Zeit.",
    photo: {
      src: "/team-photo.jpg",
      alt: "Unser KI-Team aus Frankfurt"
    },
    stats: [
      { number: "20+", label: "Zufriedene Kunden" },
      { number: "95%", label: "Erfolgsrate" },
      { number: "24/7", label: "Support" }
    ]
  },
  // Blog Section
  blog: {
    title: "KI-Marketing Insights",
    subtitle: "Bleiben Sie auf dem neuesten Stand der KI-Marketing-Entwicklungen",
    cta: {
      title: "Bleiben Sie informiert",
      description: "Abonnieren Sie unseren Newsletter und erhalten Sie die neuesten KI-Marketing-Insights direkt in Ihren Posteingang.",
      buttons: {
        primary: "Newsletter abonnieren",
        secondary: "Alle Artikel ansehen"
      }
    }
  },
  // Contact Section
  contact: {
    title: "Kontaktieren Sie uns",
    subtitle: "Lassen Sie uns gemeinsam Ihre KI-Strategie entwickeln",
    form: {
      name: "Name",
      email: "E-Mail",
      company: "Unternehmen",
      message: "Ihre Nachricht",
      submit: "Nachricht senden"
    },
    info: {
      address: "Frankfurt am Main, Deutschland",
      email: "info@ki-marketing-frankfurt.de",
      phone: "+49 69 123 456 78"
    }
  }
};

const navItems = homepageContent.navigation.menu;
const Navigation = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const [isServicesHovered, setIsServicesHovered] = useState(false);
  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);
  const scrollToSection = (href) => {
    const isHomepage = window.location.pathname === "/" || window.location.pathname === "/index.html";
    if (href === "#contact" && !isHomepage) {
      const element = document.querySelector(href);
      if (element) {
        element.scrollIntoView({ behavior: "smooth" });
      }
    } else if (isHomepage) {
      const element = document.querySelector(href);
      if (element) {
        element.scrollIntoView({ behavior: "smooth" });
      }
    } else {
      window.location.href = `/${href}`;
    }
    setIsOpen(false);
  };
  const handleLogoClick = () => {
    window.location.href = "/";
  };
  return /* @__PURE__ */ jsx("nav", { className: `fixed top-0 w-full z-50 transition-all duration-300 ${isScrolled || isOpen ? "bg-background/95 backdrop-blur-md border-b border-border" : "bg-transparent"}`, children: /* @__PURE__ */ jsxs("div", { className: "max-w-7xl mx-auto px-6", children: [
    /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between h-20", children: [
      /* @__PURE__ */ jsxs(
        "button",
        {
          onClick: handleLogoClick,
          className: "flex items-center space-x-2 text-left",
          "aria-label": "Zur Startseite",
          children: [
            /* @__PURE__ */ jsx("div", { className: "w-10 h-10 border-2 border-blue-600 rounded-lg flex items-center justify-center", children: /* @__PURE__ */ jsx("span", { className: "text-white font-bold text-sm", children: "KI" }) }),
            /* @__PURE__ */ jsx("span", { className: "text-xl font-bold", children: homepageContent.navigation.logo })
          ]
        }
      ),
      /* @__PURE__ */ jsx("div", { className: "hidden md:flex items-center space-x-8", children: navItems.map((item) => {
        if (item.label === "Services") {
          return /* @__PURE__ */ jsxs(
            "div",
            {
              className: "relative",
              onMouseEnter: () => setIsServicesHovered(true),
              onMouseLeave: () => setIsServicesHovered(false),
              children: [
                /* @__PURE__ */ jsx(
                  "button",
                  {
                    onClick: () => scrollToSection(item.href),
                    className: "text-muted-foreground hover:text-foreground transition-colors font-medium",
                    children: item.label
                  }
                ),
                isServicesHovered && /* @__PURE__ */ jsx("div", { className: "absolute top-full left-0 w-48 bg-background border border-border rounded-lg shadow-lg z-50", children: /* @__PURE__ */ jsx(
                  "a",
                  {
                    href: "/ki-automatisierung",
                    className: "block px-4 py-3 text-sm text-muted-foreground hover:text-foreground hover:bg-muted/50 transition-colors",
                    children: "KI Automatisierung"
                  }
                ) })
              ]
            },
            item.label
          );
        }
        return /* @__PURE__ */ jsx(
          "button",
          {
            onClick: () => scrollToSection(item.href),
            className: "text-muted-foreground hover:text-foreground transition-colors font-medium",
            children: item.label
          },
          item.label
        );
      }) }),
      /* @__PURE__ */ jsx("div", { className: "hidden md:block", children: /* @__PURE__ */ jsx(
        Button,
        {
          onClick: () => scrollToSection("#contact"),
          className: "bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white border-0",
          children: homepageContent.navigation.cta
        }
      ) }),
      /* @__PURE__ */ jsx(
        "button",
        {
          onClick: () => setIsOpen(!isOpen),
          className: "md:hidden p-2 text-muted-foreground hover:text-foreground transition-colors",
          children: isOpen ? /* @__PURE__ */ jsx(X, { className: "w-6 h-6" }) : /* @__PURE__ */ jsx(Menu, { className: "w-6 h-6" })
        }
      )
    ] }),
    isOpen && /* @__PURE__ */ jsxs("div", { className: "md:hidden py-6 border-t border-border bg-background/95 backdrop-blur-md", children: [
      /* @__PURE__ */ jsxs("div", { className: "flex flex-col space-y-4", children: [
        navItems.map((item) => /* @__PURE__ */ jsx(
          "button",
          {
            onClick: () => scrollToSection(item.href),
            className: "text-left text-muted-foreground hover:text-foreground transition-colors font-medium py-2",
            children: item.label
          },
          item.label
        )),
        /* @__PURE__ */ jsx(
          Button,
          {
            onClick: () => scrollToSection("#contact"),
            className: "w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white border-0",
            children: homepageContent.navigation.cta
          }
        )
      ] }),
      /* @__PURE__ */ jsx("div", { className: "h-8" })
    ] })
  ] }) });
};

const Input = React.forwardRef(
  ({ className, type, ...props }, ref) => {
    return /* @__PURE__ */ jsx(
      "input",
      {
        type,
        className: cn(
          "flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-base ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium file:text-foreground placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 md:text-sm",
          className
        ),
        ref,
        ...props
      }
    );
  }
);
Input.displayName = "Input";

const Textarea = React.forwardRef(
  ({ className, ...props }, ref) => {
    return /* @__PURE__ */ jsx(
      "textarea",
      {
        className: cn(
          "flex min-h-[80px] w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50",
          className
        ),
        ref,
        ...props
      }
    );
  }
);
Textarea.displayName = "Textarea";

const Contact = () => {
  return /* @__PURE__ */ jsx("section", { id: "contact", className: "py-24 px-6 bg-muted/30", children: /* @__PURE__ */ jsxs("div", { className: "max-w-7xl mx-auto", children: [
    /* @__PURE__ */ jsxs("div", { className: "text-center mb-16", children: [
      /* @__PURE__ */ jsxs("h2", { className: "text-4xl md:text-5xl font-bold mb-6", children: [
        "Bereit, Ihr Marketing zu ",
        /* @__PURE__ */ jsx("span", { className: "text-gradient", children: "transformieren" }),
        "?"
      ] }),
      /* @__PURE__ */ jsx("p", { className: "text-xl text-muted-foreground max-w-3xl mx-auto", children: "Lassen Sie uns gemeinsam die Kraft der KI nutzen, um Ihr Unternehmen in Frankfurt und darüber hinaus zum Erfolg zu führen. Kontaktieren Sie uns für eine kostenlose Beratung." })
    ] }),
    /* @__PURE__ */ jsx("div", { className: "max-w-2xl mx-auto", children: /* @__PURE__ */ jsxs(
      "form",
      {
        name: "contact",
        method: "POST",
        "data-netlify": "true",
        "netlify-honeypot": "bot-field",
        action: "/thank-you",
        className: "space-y-6",
        children: [
          /* @__PURE__ */ jsx("input", { type: "hidden", name: "form-name", value: "contact" }),
          /* @__PURE__ */ jsx("p", { className: "hidden", children: /* @__PURE__ */ jsxs("label", { children: [
            "Nicht ausfüllen: ",
            /* @__PURE__ */ jsx("input", { name: "bot-field" })
          ] }) }),
          /* @__PURE__ */ jsx("h3", { className: "text-2xl font-semibold mb-6 text-center", children: "Senden Sie uns eine Nachricht" }),
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx("label", { className: "block text-sm font-medium mb-2", children: "Name" }),
            /* @__PURE__ */ jsx(Input, { name: "name", placeholder: "Ihr Name", required: true })
          ] }),
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx("label", { className: "block text-sm font-medium mb-2", children: "E-Mail" }),
            /* @__PURE__ */ jsx(Input, { type: "email", name: "email", placeholder: "ihre.email@beispiel.de", required: true })
          ] }),
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx("label", { className: "block text-sm font-medium mb-2", children: "Nachricht" }),
            /* @__PURE__ */ jsx(Textarea, { name: "message", placeholder: "Erzählen Sie uns von Ihrem Projekt und wie wir Ihnen helfen können...", rows: 5, required: true })
          ] }),
          /* @__PURE__ */ jsxs(Button, { type: "submit", className: "w-full py-3", children: [
            /* @__PURE__ */ jsx(Send, { className: "w-4 h-4 mr-2" }),
            "Nachricht senden"
          ] })
        ]
      }
    ) })
  ] }) });
};

const Footer = () => {
  const currentYear = (/* @__PURE__ */ new Date()).getFullYear();
  return /* @__PURE__ */ jsx("footer", { className: "bg-muted/50 border-t border-border py-8 px-6", children: /* @__PURE__ */ jsx("div", { className: "max-w-7xl mx-auto", children: /* @__PURE__ */ jsxs("div", { className: "flex flex-col md:flex-row justify-between items-center gap-4", children: [
    /* @__PURE__ */ jsxs("div", { className: "text-sm text-muted-foreground", children: [
      "© ",
      currentYear,
      " KI Agentur Frankfurt. Alle Rechte vorbehalten."
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-6 text-sm", children: [
      /* @__PURE__ */ jsx(
        "a",
        {
          href: "/impressum",
          className: "text-muted-foreground hover:text-foreground transition-colors",
          children: "Impressum"
        }
      ),
      /* @__PURE__ */ jsx(
        "a",
        {
          href: "/datenschutz",
          className: "text-muted-foreground hover:text-foreground transition-colors",
          children: "Datenschutz"
        }
      )
    ] })
  ] }) }) });
};

export { Button as B, Contact as C, Footer as F, Navigation as N, cn as c, homepageContent as h };
