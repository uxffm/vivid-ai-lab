const _astro_assetImports = new Map();

export { _astro_assetImports as default };
