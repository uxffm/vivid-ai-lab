import { b as createAstro, c as createComponent, r as renderTemplate, a as renderComponent, f as renderSlot, e as renderHead, u as unescapeHTML, d as addAttribute } from './astro/server.DJBOAiLl.js';
import 'kleur/colors';
/* empty css                         */
import { jsx } from 'react/jsx-runtime';
import { useTheme } from 'next-themes';
import { Toaster as Toaster$1 } from 'sonner';

const Toaster = ({ ...props }) => {
  const { theme = "system" } = useTheme();
  return /* @__PURE__ */ jsx(
    Toaster$1,
    {
      theme,
      className: "toaster group",
      toastOptions: {
        classNames: {
          toast: "group toast group-[.toaster]:bg-background group-[.toaster]:text-foreground group-[.toaster]:border-border group-[.toaster]:shadow-lg",
          description: "group-[.toast]:text-muted-foreground",
          actionButton: "group-[.toast]:bg-primary group-[.toast]:text-primary-foreground",
          cancelButton: "group-[.toast]:bg-muted group-[.toast]:text-muted-foreground"
        }
      },
      ...props
    }
  );
};

var __freeze = Object.freeze;
var __defProp = Object.defineProperty;
var __template = (cooked, raw) => __freeze(__defProp(cooked, "raw", { value: __freeze(cooked.slice()) }));
var _a;
const $$Astro = createAstro("https://frankfurt-ai.de");
const $$Layout = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$Layout;
  const {
    title,
    description = "KI-Marketing Agentur in Frankfurt - Wir revolutionieren Ihr digitales Marketing mit k\xFCnstlicher Intelligenz. Ma\xDFgeschneiderte KI-L\xF6sungen f\xFCr messbare Ergebnisse.",
    image = "/src/assets/ai-hero-image.jpg",
    type = "website",
    publishedTime,
    modifiedTime,
    author = "KI Marketing Frankfurt",
    noindex = false
  } = Astro2.props;
  const canonicalURL = new URL(Astro2.url.pathname, Astro2.site);
  return renderTemplate(_a || (_a = __template([`<html lang="de" class="dark"> <head><meta charset="UTF-8"><!-- Google tag (gtag.js) --><script async src="https://www.googletagmanager.com/gtag/js?id=G-HGXHZVR4LV"><\/script><script>
      window.dataLayer = window.dataLayer || [];
      function gtag(){ dataLayer.push(arguments); }
      gtag('js', new Date());
      gtag('config', 'G-HGXHZVR4LV');
    <\/script><meta name="viewport" content="width=device-width, initial-scale=1.0"><meta name="description"`, '><meta name="author"', '><meta name="robots"', '><!-- Canonical URL --><link rel="canonical"', '><!-- Open Graph / Facebook --><meta property="og:type"', '><meta property="og:url"', '><meta property="og:title"', '><meta property="og:description"', '><meta property="og:image"', '><meta property="og:site_name" content="KI Marketing Frankfurt"><meta property="og:locale" content="de_DE"><!-- Twitter --><meta property="twitter:card" content="summary_large_image"><meta property="twitter:url"', '><meta property="twitter:title"', '><meta property="twitter:description"', '><meta property="twitter:image"', '><!-- Additional SEO Meta Tags --><meta name="keywords" content="KI-Marketing, K\xFCnstliche Intelligenz, Marketing Agentur, Frankfurt, Digital Marketing, AI Marketing, Machine Learning Marketing"><meta name="geo.region" content="DE-HE"><meta name="geo.placename" content="Frankfurt am Main"><meta name="geo.position" content="50.1109;8.6821"><meta name="ICBM" content="50.1109, 8.6821"><!-- Article specific meta tags -->', "", "", '<!-- Favicon --><link rel="icon" type="image/svg+xml" href="/favicon.svg"><link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon.png"><link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png"><link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png"><!-- Preconnect to external domains --><link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin><meta name="generator"', "><title>", '</title><!-- Structured Data --><script type="application/ld+json">', "<\/script>", '</head> <body class="dark"> ', ' <!-- Hidden static Netlify form for detection at build time --> <form name="contact" method="POST" data-netlify="true" netlify-honeypot="bot-field" hidden> <input type="hidden" name="form-name" value="contact"> <input type="text" name="firstName"> <input type="text" name="lastName"> <input type="email" name="email"> <textarea name="message"></textarea> <p class="hidden"><label>Don\u2019t fill this out: <input name="bot-field"></label></p> </form> ', " </body></html>"])), addAttribute(description, "content"), addAttribute(author, "content"), addAttribute(noindex ? "noindex, nofollow" : "index, follow", "content"), addAttribute(canonicalURL, "href"), addAttribute(type, "content"), addAttribute(canonicalURL, "content"), addAttribute(title, "content"), addAttribute(description, "content"), addAttribute(new URL(image, Astro2.site), "content"), addAttribute(canonicalURL, "content"), addAttribute(title, "content"), addAttribute(description, "content"), addAttribute(new URL(image, Astro2.site), "content"), publishedTime && renderTemplate`<meta property="article:published_time"${addAttribute(publishedTime, "content")}>`, modifiedTime && renderTemplate`<meta property="article:modified_time"${addAttribute(modifiedTime, "content")}>`, author && renderTemplate`<meta property="article:author"${addAttribute(author, "content")}>`, addAttribute(Astro2.generator, "content"), title, unescapeHTML(JSON.stringify({
    "@context": "https://schema.org",
    "@type": "Organization",
    "name": "KI Marketing Frankfurt",
    "url": "https://ki-marketing-frankfurt.de",
    "logo": "https://ki-marketing-frankfurt.de/logo.png",
    "description": description,
    "address": {
      "@type": "PostalAddress",
      "streetAddress": "Kaiserstra\xDFe 123",
      "addressLocality": "Frankfurt am Main",
      "postalCode": "60311",
      "addressCountry": "DE"
    },
    "contactPoint": {
      "@type": "ContactPoint",
      "telephone": "+49-69-123-456-78",
      "contactType": "customer service",
      "email": "info@ki-marketing-frankfurt.de"
    },
    "sameAs": [
      "https://www.linkedin.com/company/ki-marketing-frankfurt",
      "https://www.xing.com/companies/ki-marketing-frankfurt"
    ]
  })), renderHead(), renderSlot($$result, $$slots["default"]), renderComponent($$result, "SonnerToaster", Toaster, { "client:load": true, "client:component-hydration": "load", "client:component-path": "/Users/lukasz/Desktop/vivid-ai-lab/src/components/ui/sonner", "client:component-export": "Toaster" }));
}, "/Users/lukasz/Desktop/vivid-ai-lab/src/layouts/Layout.astro", void 0);

export { $$Layout as $ };
